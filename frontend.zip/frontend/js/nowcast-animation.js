class NowcastAnimation {
    constructor(options = {}) {
        this.imageElement = document.querySelector(
            options.imageSelector || "#nowcastImage"
        );

        this.slider = document.querySelector(
            options.sliderSelector || "#nowcastSlider"
        );

        this.timeLabel = document.querySelector(
            options.timeLabelSelector || "#nowcastTime"
        );

        this.playButton = document.querySelector(
            options.playButtonSelector || "#playNowcast"
        );

        this.statusLabel = document.querySelector(
            options.statusSelector || "#nowcastStatus"
        );

        this.frames = options.frames || [];
        this.currentFrame = 0;
        this.isPlaying = false;
        this.timer = null;
        this.interval = options.interval || 800;

        this.init();
    }

    init() {
        if (this.slider) {
            this.slider.max = Math.max(this.frames.length - 1, 0);

            this.slider.addEventListener("input", (event) => {
                this.stop();
                this.showFrame(Number(event.target.value));
            });
        }

        if (this.playButton) {
            this.playButton.addEventListener("click", () => {
                this.togglePlay();
            });
        }

        this.showFrame(0);
    }

    showFrame(index) {
        if (!this.frames.length || !this.imageElement) return;

        this.currentFrame = index;

        const frame = this.frames[index];

        this.imageElement.src = frame.image;

        if (this.timeLabel) {
            this.timeLabel.textContent = frame.label;
        }

        if (this.statusLabel) {
            this.statusLabel.textContent = frame.type === "forecast"
                ? "FORECAST"
                : "OBSERVED";
        }

        if (this.slider) {
            this.slider.value = index;
        }
    }

    play() {
        if (this.isPlaying || this.frames.length <= 1) return;

        this.isPlaying = true;
        this.updateButton();

        this.timer = setInterval(() => {
            let nextFrame = this.currentFrame + 1;

            if (nextFrame >= this.frames.length) {
                nextFrame = 0;
            }

            this.showFrame(nextFrame);
        }, this.interval);
    }

    stop() {
        this.isPlaying = false;

        if (this.timer) {
            clearInterval(this.timer);
            this.timer = null;
        }

        this.updateButton();
    }

    togglePlay() {
        if (this.isPlaying) {
            this.stop();
        } else {
            this.play();
        }
    }

    updateButton() {
        if (!this.playButton) return;

        this.playButton.textContent = this.isPlaying
            ? "⏸ Pause Forecast"
            : "▶ Play Forecast";
    }
}